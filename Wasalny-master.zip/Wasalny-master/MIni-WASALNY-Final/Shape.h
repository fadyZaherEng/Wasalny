#pragma once
#include<iostream>
#include<conio.h>
#include"Functions.h"
void shape(int width, int height);
void AppStart();