#include<iostream>
#include"Graph.h"
#include"Shape.h"
using namespace std;
int main() {

	AppStart();
	system("pause");
}
